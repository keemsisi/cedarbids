import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bidding-progress',
  templateUrl: './bidding-progress.component.html',
  styleUrls: ['./bidding-progress.component.css']
})
export class BiddingProgressComponent implements OnInit {

  data: any ;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.data  = this.route.snapshot.data ; // the resolved data ;
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BiddingProgressComponent } from './bidding-progress.component';

describe('BiddingProgressComponent', () => {
  let component: BiddingProgressComponent;
  let fixture: ComponentFixture<BiddingProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BiddingProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiddingProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

class ContractorDashboardlanding {
    totalBidsApplied: number ;
    bidAwarded: number ;
}

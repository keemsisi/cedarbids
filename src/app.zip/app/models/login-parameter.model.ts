 class LoginParameter {
    username: string ;
    password: string ;
}

class BiddingProgress {

}

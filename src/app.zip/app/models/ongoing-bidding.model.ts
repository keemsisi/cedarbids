class OgoingBidding {

}

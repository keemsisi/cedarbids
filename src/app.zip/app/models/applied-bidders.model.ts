class AppliedBidders {
}

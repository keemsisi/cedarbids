class Message {
    sender: string ;
    dateSent: string ;
    messageText: Blob ;
}


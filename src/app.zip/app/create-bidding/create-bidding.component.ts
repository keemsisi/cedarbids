import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpCustomService } from '../services/http-custom.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-create-bidding',
  templateUrl: './create-bidding.component.html',
  styleUrls: ['./create-bidding.component.css']
})
export class CreateBiddingComponent implements OnInit {

  newBidForm: FormGroup;
  biddingFiles:any = '' ;

  constructor(
    private customHttpService: HttpCustomService ,
    private activatedRoute: ActivatedRoute,
    private router: Router, private fb: FormBuilder
    ) {
      this.newBidForm = this.fb.group({
        title: new FormControl(''),
        description: new FormControl(''),
        start: new FormControl(''),
        end: new FormControl(''),
        files:new FormControl(''),

      });
  }

  ngOnInit() {
  }


  biddingFilesChange() {
    console.log('The Bidding Files Collected', this.biddingFiles)
  }

}
 
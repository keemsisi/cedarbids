import { ValidatorFn, ValidationErrors, FormGroup } from '@angular/forms';

export const customValidator: ValidatorFn =
        (control: FormGroup): ValidationErrors | null => {
            const nameField = control.get('name');
            const schoolField = control.get('school');

            // return the null when there is no error
            return nameField === schoolField ? {errorPersisted: true } : null ;
        };

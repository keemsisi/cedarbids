import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allbids',
  templateUrl: './allbids.component.html',
  styleUrls: ['./allbids.component.css']
})
export class AllbidsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

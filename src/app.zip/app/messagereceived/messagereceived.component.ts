import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messagereceived',
  templateUrl: './messagereceived.component.html',
  styleUrls: ['./messagereceived.component.css']
})
export class MessagereceivedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

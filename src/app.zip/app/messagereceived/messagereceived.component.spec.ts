import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagereceivedComponent } from './messagereceived.component';

describe('MessagereceivedComponent', () => {
  let component: MessagereceivedComponent;
  let fixture: ComponentFixture<MessagereceivedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessagereceivedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagereceivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

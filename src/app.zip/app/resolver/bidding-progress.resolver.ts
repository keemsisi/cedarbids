import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpCustomService } from '../services/http-custom.service';
import { Observable } from 'rxjs';


// bidding progress rosolver
@Injectable()
export class BiddingProgressResolver  {
  constructor(private http: HttpCustomService ) {

}
}

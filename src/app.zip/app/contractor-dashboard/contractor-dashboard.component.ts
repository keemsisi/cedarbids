import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contractor-dashboard',
  templateUrl: './contractor-dashboard.component.html',
  styleUrls: ['./contractor-dashboard.component.css']
})
export class ContractorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { OngoingBiddingComponent } from './ongoing-bidding/ongoing-bidding.component';
import { AboutComponent } from './about/about.component';
import { RegisterationComponent } from './registeration/registeration.component';
import { VendorDashboardComponent } from './vendor-dashboard/vendor-dashboard.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CreateBiddingComponent } from './create-bidding/create-bidding.component';
import { LoginComponent } from './login/login.component';
import { AccountSettingsComponent } from './account-settings/account-settings.component';
import { ViewBiddingHistoryComponent } from './view-bidding-history/view-bidding-history.component';
import { DashboardLandingComponent } from './dashboard-landing/dashboard-landing.component';
import { BiddingProgressComponent } from './bidding-progress/bidding-progress.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router' ;
import { ContractorLoginGuard } from './guards/contractor-login.guard';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ContractorDashboardComponent } from './contractor-dashboard/contractor-dashboard.component';
import { HttpCustomService } from './services/http-custom.service';
import { CacheCustomService } from './services/cache-custom.service';
import { BiddingProgressResolver } from './resolver/bidding-progress.resolver';
import { HttpClientModule } from '@angular/common/http';
import { ForgotpasswordpageComponent } from './forgotpasswordpage/forgotpasswordpage.component';
import { AwardedprojectsComponent } from './awardedprojects/awardedprojects.component';
import { CompanyRegistrationPageComponent } from './company-registration-page/company-registration-page.component';
import { FileUploadModule, MessageService } from 'primeng/primeng';
// import { PanelModule } from 'primeng/primeng';
// import { ButtonModule } from 'primeng/primeng';
// import { RadioButtonModule } from 'primeng/primeng';
import {MessagesModule} from 'primeng/messages';
import {ToastModule} from 'primeng/toast';
import {MessageModule} from 'primeng/message';

import {
  MatInputModule,
  MatButtonModule,
  MatMenuModule,
  MatIconModule,
  MatFormFieldModule,
  MatToolbarModule,
  MatOptionModule,
  MatSelectModule,
  MatStepperModule,
  MatBadgeModule,
  MatExpansionModule,
  MatButtonToggleModule,
  MatAutocompleteModule,
  MatBottomSheetModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDividerModule,
  MatListModule,
  MatDatepickerModule,
  MatCommonModule,
  MatDialogModule,
  MatTabsModule,
  MatRadioModule,
  MatTableModule
} from '@angular/material';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';





// import { from } from 'rxjs';
import { CountryCodeService } from './services/country-code.service';
import { CompanyServicesService } from './services/company-services.service';
import { ApplicationContainerComponent } from './application-container/application-container.component';
import { SubscriptionPageComponent } from './subscription-page/subscription-page.component';
import { MessagereceivedComponent } from './messagereceived/messagereceived.component';
import { MessagesentComponent } from './messagesent/messagesent.component';
import { UpdatebidsComponent } from './updatebids/updatebids.component';
import { AllbidsComponent } from './allbids/allbids.component';
import { BidsStatisticsComponent } from './bids-statistics/bids-statistics.component';
import { ActivityLogComponent } from './activity-log/activity-log.component';
import { ServerErrorComponent } from './server-error/server-error.component';
import { AccountBillingComponent } from './account-billing/account-billing.component';




@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    OngoingBiddingComponent,
    AboutComponent,
    RegisterationComponent,
    VendorDashboardComponent,
    ContactUsComponent,
    CreateBiddingComponent,
    LoginComponent,
    ApplicationContainerComponent,
    AccountSettingsComponent,
    ViewBiddingHistoryComponent,
    DashboardLandingComponent,
    BiddingProgressComponent,
    ContractorDashboardComponent,
    PagenotfoundComponent,
    ForgotpasswordpageComponent,
    AwardedprojectsComponent,
    CompanyRegistrationPageComponent,
    ApplicationContainerComponent,
    SubscriptionPageComponent,
    MessagereceivedComponent,
    MessagesentComponent,
    UpdatebidsComponent,
    AllbidsComponent,
    UpdatebidsComponent,
    MessagereceivedComponent,
    SubscriptionPageComponent,
    BidsStatisticsComponent,
    ActivityLogComponent,
    ServerErrorComponent,
    AccountBillingComponent
  ],


  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    FormsModule,
    MatDialogModule,
    MatExpansionModule,
    MatBadgeModule,
    MatOptionModule,
    MatSelectModule,
    MatButtonModule,
    FileUploadModule,
    MatRadioModule,
    MatMenuModule,
    MatTableModule,
    MatToolbarModule,
    MatIconModule,
    MatTabsModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDividerModule,
    MatStepperModule,
    MatBadgeModule,
    MatButtonToggleModule,
    MatAutocompleteModule,
    MatBottomSheetModule,
    MatListModule,
    MatDatepickerModule,
    MatCommonModule,
    MatCardModule,
    MatInputModule,
    BrowserAnimationsModule,
    HttpModule,
    MessageModule, MessagesModule, ToastModule,


    RouterModule.forRoot([
      {path : '' , component : HomepageComponent},
      {path: 'awarded-projects', component: AwardedprojectsComponent},
      {path : 'management', component : ContactUsComponent},
      {path : 'contact', component : ContactUsComponent},
      {path:  'about', component: AboutComponent},
      {path : 'ongoing-bidding' , component : OngoingBiddingComponent},
      {path : 'company-registration' , component : CompanyRegistrationPageComponent},
      {path : 'login' , component : LoginComponent},
      {path: 'forgot-password-page', component : ForgotpasswordpageComponent},
      // {path : 'create-bidding' , component : CreateBiddingComponent, canActivate : [ContractorLoginGuard]},


      { path : 'contractor-dashboard' ,
      component : ContractorDashboardComponent,
      canActivate : [ContractorLoginGuard], children: [

        {path : '' , component : VendorDashboardComponent , canActivate: [ContractorLoginGuard]},
        {path : 'create-bidding' , component : CreateBiddingComponent, canActivate : [ContractorLoginGuard]},
        {path : 'view-bidding-history' , component : ViewBiddingHistoryComponent , canActivate: [ContractorLoginGuard]},
        {path : 'landing' , component : VendorDashboardComponent , canActivate: [ContractorLoginGuard]},
        {path : 'account-settings' , component : AccountSettingsComponent , canActivate: [ContractorLoginGuard]},
        {path : 'bidding-progress', component : BiddingProgressComponent , canActivate : [ContractorLoginGuard]},
        {path: 'contractor-allbids', component: AllbidsComponent, canActivate : [ContractorLoginGuard]},
        {path: 'contractor-subscription-page', component: SubscriptionPageComponent, canActivate : [ContractorLoginGuard]},
        {path: 'contractor-message-recieved', component: MessagereceivedComponent, canActivate : [ContractorLoginGuard]},
        {path: 'contractor-updatebids', component: UpdatebidsComponent, canActivate : [ContractorLoginGuard]},
        {path: 'contractor-bids-statistics', component: BidsStatisticsComponent, canActivate : [ContractorLoginGuard]},
        {path: 'account-billing', component: AccountBillingComponent, canActivate : [ContractorLoginGuard]},
        {path: 'messagesreceived', component: MessagereceivedComponent, canActivate : [ContractorLoginGuard]}


      ]},


      {path : '**', component : PagenotfoundComponent}
    ])
  ],

  providers: [
    HttpCustomService, MessageService ,
    CacheCustomService, BiddingProgressResolver,
     CountryCodeService, CompanyServicesService
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }

import { TestBed, async, inject } from '@angular/core/testing';

import { ContractorLoginGuard } from './contractor-login.guard';

describe('ContractorLoginGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContractorLoginGuard]
    });
  });

  it('should ...', inject([ContractorLoginGuard], (guard: ContractorLoginGuard) => {
    expect(guard).toBeTruthy();
  }));
});

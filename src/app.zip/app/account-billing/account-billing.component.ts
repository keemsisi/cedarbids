import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-account-billing',
  templateUrl: './account-billing.component.html',
  styleUrls: ['./account-billing.component.css']
})
export class AccountBillingComponent implements OnInit {

  someValue: string;
  constructor() { }


  @Input()
  @Output() counterChange = new EventEmitter();
  get something() {
    console.log('hello');
    this.counterChange.emit('rererer');
    return 3434;
  }


  ngOnInit() {
  }

}

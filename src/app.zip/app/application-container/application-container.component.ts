import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application-container',
  templateUrl: './application-container.component.html',
  styleUrls: ['./application-container.component.css']
})
export class ApplicationContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { log } from 'util';
import { FormControl, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-forgotpasswordpage',
  templateUrl: './forgotpasswordpage.component.html',
  styleUrls: ['./forgotpasswordpage.component.css']
})
export class ForgotpasswordpageComponent implements OnInit {
  _controller: FormControl = new FormControl('', Validators.email);
  myNewFormGroup : FormGroup =  new FormGroup({
    _controller2: new FormControl('', [Validators.email])

  });

  email: FormControl = new FormControl('',[Validators.email]) ;

  constructor() {
    // setInterval(() => {
    //   // console.log('DIRTY',this._controller.dirty);
    //   // console.log('predistine',this._controller.pristine);
    //   // console.log('touched', this._controller.touched);
    //   // console.log('Untouched',this._controller.untouched);
    //   // console.log('EMAIL',this._controller.hasError('email'));
    //   // console.log('VALID',this._controller.valid);

    //   console.log(this.myNewFormGroup.controls._controller2.valid)
    //   console.log(this.myNewFormGroup.controls._controller2.dirty)
    //   console.log(this.myNewFormGroup.controls._controller2.touched)
    //   console.log(this.myNewFormGroup.controls._controller2.untouched)
    //   console.log(this.myNewFormGroup.controls._controller2.status)

    // }, 1000
    //);


    }
  ngOnInit() { 
  }


}

import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators, FormArray, AbstractControl, ValidationErrors, ValidatorFn} from '@angular/forms' ;
import { CountryCodeService } from '../services/country-code.service';
import { AvailaibleGoodsAndServeService } from '../services/availaible-goods-and-serve.service';
import { HttpCustomService } from '../services/http-custom.service';
import { MatCheckboxChange } from '@angular/material';
import { Observable } from 'rxjs';
import { Event, ResolveEnd } from '@angular/router';
import { reject } from 'q';
import {MessageService} from 'primeng/api';


@Component({
  selector: 'app-company-registration-page',
  templateUrl: './company-registration-page.component.html',
  styleUrls: ['./company-registration-page.component.css']
})
export class CompanyRegistrationPageComponent implements OnInit {

    // countryEntities: {[countryAbbrive: string]: {name: string, iso2: string, code: string}} = {};

    countryEntities: Array<Object> = [];



    /**
     * The following below is the form sections that the company will fill in the mat -stepper form fields
     * 
     */

    // testing environment we use the linear and the non-linear case
    isLinear = true;
    isCompleted1 = false;
    isCompleted2 = false;
    isCompleted3 = false;
    isCompleted4 = false;
    isCompleted5 = false;
    isCompleted6 = false;
    isCompleted7 = true;

    arrayBufferResult:ArrayBuffer ;
    financiaFiles= [] ;
    techFiles= [] ;
    compCertFiles= [] ;
    results = [] ;


    // mssage for display
    techFilesUploadSuccess = [] ;
    financialFileUploadSuccess = [] ;
    compCertFilesUploadSuccess = [] ;

    // error array
    errorMessage = [] ;



    servicesChecked: Array<string> = [];
    goodsAndServies: Array<string> = []; // and Information of Goods/Services Offered
    languages: Array<string> = ['English', 'French', 'Russian', 'Yoruba'];
    natureOfBusiness: Array<string> = ['Manufacturer', 'Trader', 'Authorised Agent', 'Consulting Company', 'Other'];
    typeOfBusiness: Array<string> = ['Corporate / Limited', 'Partnership', 'Government Agency', 'University', 'Other' ];
    amountSymbol: Array<string> = ['NGN', 'EUR', 'USD', 'POUNDS', 'YEN'];



    generalCompanyInfoSection: FormGroup; // used for holding the form group...
    companyAccessInfo: FormGroup ; // used for holding the form group...
    logginCredentialSection: FormGroup ; // log in credentials for the company
    servicesSection: FormGroup ; // services the company provide
    finalcialInformationSection: FormGroup ; // hold the financial status of the company
    techCapability: FormGroup ;  // Techinical capability'
    othersSection: FormGroup ; // otthers section


    /**
     * This is the form data to send to the application server
     */
     formDataToSend: {[section: string]: InterfaceGetAll } = {} ;






    /**
     * This will hold the Array  of inputs for the company experinces
     */
    experiencesSection: FormGroup;




    private _securityControlQuestion = [] ;
    private _serviceOffered: [] ;


    // private _nameclass = ;
  constructor(
    private  fb: FormBuilder, private countryCodeService: CountryCodeService,
    private servicesOffering: AvailaibleGoodsAndServeService,
    private serverHttpCall: HttpCustomService, private messageService: MessageService) {
      // collects the returned value and store it in the goodsAndServices array
    this.goodsAndServies = this.servicesOffering.servicesOffering ;

    console.log(this.goodsAndServies);
    console.log(new FormControl());



    
    /**Stores the returned value from the CountryCodeService  */
    this.countryEntities = this.countryCodeService.countryArrayObjects ;

    this._securityControlQuestion.push(' What is the year your company was establised ?');
    this._securityControlQuestion.push(' What is your company colour ? ');
    this._securityControlQuestion.push(' What is the full CEO"s name ?');
    this._securityControlQuestion.push('What is the name of your company contact person ?');



    /**
     * company general information section
     */
    this.generalCompanyInfoSection = fb.group({
      // mat stepper for the registeration form

      companyName : new FormControl('',Validators.required) ,
      companyAddresses : this.fb.array([this.initAddress()]),
      poBoxAddress: new FormControl('', []),
      mailingAddress: new FormControl('', [Validators.required]),
      telephones: this.fb.array([this.initTelephone()]),
      emailAddresses: fb.array([this.initEmailAddress()]),
      websiteAddress: new FormControl('',
      Validators.pattern(/[https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,60}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/)),
      contactPerson: new FormControl('', Validators.required),
      ownershipAndparentCompany: new FormControl('', Validators.required),
      nameAndAddressOfSubsidiary: this.fb.array([this.initSubsidiary()]),
      natureOfBusiness: new FormControl('', Validators.required),

      typeOfBusiness: new FormControl('', Validators.required),

      yearOfEstablished: new FormControl('', [Validators.required,Validators.pattern(/[0-9]{4}/)]),
      numberOfEmployees: new FormControl('', [Validators.required ,Validators.pattern(/[0-9]*/)]),
      vatNumberOrTaxid: new FormControl('', [Validators.required ,Validators.pattern(/[0-9]*-[0-9]*/)]),
      LicenceNoOrStateWhereRegistered: new FormControl('', [Validators.required , Validators.pattern(/[0-9]*||[a-zA-Z]*/)]),

      technicalDocumentsAvailableIn: new FormControl('', Validators.required),
      workingLanguages: new FormControl('')
      });


    this.techCapability =  fb.group({
      /**
       * This will control the latest certificates that the company the company has
       * Qaulity of Assurance Certification
       * General Civil Authority Certification (GAAC)
       */
      // work on this to have array of international offices fileds
      interantionalOffices: new FormControl('', Validators.pattern(/[a-zA-Z]*/)),
      services: new FormControl(''),
      techFilesDir: new FormControl('')
    });

    this.finalcialInformationSection = fb.group({
        year_amount: fb.array([
          /**
           * Creates another form group
           * year3: new FormControl(), year3Amount: new FormControl()
           *
           * */
          this.initFinalcialYearAmount()
        ]), // holds a form group of year and the year usd


      // this control will hold the certificates the company has

      annualValofExportSalesLstYrs: this.fb.array([this.initAnnualValofExportSaleslstYrs()]),

        bankName: new FormControl('',[Validators.pattern(/[a-zA-Z]*/)]),
        swift_BicAddress: new FormControl(),
        bankAccountNumber: new FormControl('',Validators.pattern(/[0-9]{10}/)),
        accountName: new FormControl('', Validators.pattern(/[a-zA-Z]/)),
        financialFolderDir: new FormControl('')
      });

    // this.finalcialInformationSection.addControl('finalcialReportFiles').value = this.finalcialReportFiles;


    /**
     * The logging credendentials of the company
     */
    this.logginCredentialSection = fb.group({
      userName : new FormControl('', [Validators.required, Validators.pattern(/[a-zA-Z]*/)]),
      password: new FormControl('', [Validators.required, Validators.min(8)] ),
      emailAddress: new FormControl('', [Validators.required, Validators.email] ),
      securityQuestion:new FormControl('', [Validators.required] ),
      securityQuestionAnswer: new FormControl('', [Validators.required ] ),
      companyLogo: new FormControl('', [] ),
      confirmPassword : new FormControl('', [Validators.required, Validators.min(8)] ),
    });

    /**
     * This will be the experiences that the company has over the years
     */

    this.experiencesSection = this.fb.group({
     experiences: this.fb.array([this.initExprience()])
    });


    this.othersSection = this.fb.group({
      questionOne: new FormControl(null),
      copyOfEnvironmentalpolicyIfyes: new FormControl(null),
      questionTwo: new FormControl(null),
      /**any national or international trade the company is a member */
      membershipList: this.fb.array([this.initMembership()]),
      certificationsDir:new FormControl(''),
}) ;


    console.log('HAS ERROR REQUIRED',
     (<FormArray>this.generalCompanyInfoSection.controls.telephones).controls[0].get('telephone').hasError('required'));


   } // end the class constrictor


   /**
    * Init Email Addresses that will be used by the company registering
    */
  initEmailAddress(): FormGroup {
    return this.fb.group({
      email: new FormControl('', Validators.email )
    });
  }

  initSubsidiary(): FormGroup {
    return this.fb.group({
      nameOfsubsidiary: new FormControl('', Validators.pattern(/[a-z]*/)),
      addressOfSubsidiary: new FormControl('',Validators.pattern(/[a-z]*/))
    });
  }

  /**
   * Add new subsidiary to the input field
   */
  addSubsidiary(): void {
   (<FormArray>this.generalCompanyInfoSection.get('subsidiaries')).push(this.initSubsidiary());
  }

  /**
   * Add new Email Address to the
   */
  addNewEmailAddress(): void {
    (<FormArray>this.generalCompanyInfoSection.get('emailAddresses')).push(this.initEmailAddress());
  }

   /**
    * This will init the membership field
    * @returns FormGroup
    */
   initMembership(): FormGroup {
      return this.fb.group({
        organisationName: new FormControl(null, Validators.pattern(/[a-zA-Z]*/))
      });
  }

  /**This add the new membership field */
  addMembership(): void {
    (<FormArray>this.othersSection.get('membershipList')).push(this.initMembership()) ;
  }


   initExprience(): FormGroup {

    return this.fb.group({
      organisation: new FormControl(''),
      currency: new FormControl(''),
      value: new FormControl(0, Validators.pattern(/[0-9]/)),
      year: new FormControl(''), // this can be the year or the date the job was done
      goodsOrServices: new FormControl(''),
      description: new FormControl('')
  });
}


/**
 * Add the experince that the company has
 * @returns Void
 */
addExperience(): void {
  (<FormArray>this.experiencesSection.get('experiences')).push(this.initExprience());
}

   /**
    * This will be the services that the company offers and the company will
    * be given oppotunity to choose services
    * @returns Array<Object>
    */
   loadServices(): Array<Object> {
      /**
       * IT ser
       */
      /*this will be returned for the services that the company offers */
      return [{}];
   }



  /**
   * @returns void
   */
  ngOnInit() {
    console.log('form is working fine for now... ');
    this.generalCompanyInfoSection.valueChanges.subscribe(
      result => console.log(this.generalCompanyInfoSection.status)
    );

    this.logginCredentialSection.valueChanges.subscribe(
      result => console.log(this.logginCredentialSection.status)
    );

    this.techCapability.valueChanges.subscribe(
      result => console.log(this.techCapability.status)
    );

    this.experiencesSection.valueChanges.subscribe(
      result => console.log(this.othersSection.status)
    );

    this.othersSection.valueChanges.subscribe(
      result => console.log(this.othersSection.status)
    );

    this.finalcialInformationSection.valueChanges.subscribe(
      result => console.log(this.finalcialInformationSection.status)
    );

    
  }

  /**
   * Returns a FormGroup Object
   */
  initFinalcialYearAmount(): FormGroup {
  return this.fb.group({
          year: new FormControl('',Validators.pattern(/[0-9]{3}/)), amount: new FormControl(0, Validators.pattern(/[0-9]*/)),
  });
  }

  /**
   * @returns Void
   * This function add another finacial field to the avalilable one
   */
  addFinalCialYearAmount(): void {
    const formArray  = <FormArray> this.finalcialInformationSection.get('year_amount');
    formArray.push(this.initFinalcialYearAmount());
  }




  /**
   * Creates ad returns a formgroup of address
   * @returns FormGroup
   */
  initAddress(): FormGroup {
    return this.fb.group({
      address: new FormControl('',Validators.required),
      postalCode: new FormControl(null,[Validators.pattern(/[0-9]*/),Validators.required]),

    });
 }


 /**
  * Adds a new address to the form field and then returns a FormGroup Object
  * @returns Void
  */
 addAddress(): void {
  const control = <FormArray>this.generalCompanyInfoSection.get('addresses');
    /**
     * Add new form control for the new for the field that will be using the formControlName
     */
    control.push(this.initTelephone());
}


  /**
   * Creates another phone number field
   * @returns FormGroup
   */
  initTelephone(): FormGroup {
    return this.fb.group({
      city: new FormControl('', [Validators.pattern(/[a-zA-Z]*/), Validators.required]),
      telephone: new FormControl('', [Validators.maxLength(15), Validators.required]),
      fax: new FormControl('', [Validators.required, Validators.pattern(/[0-9]*/)]),
    });

}


  /**
   * Returns a FormGroup Array for for the initAnnualVal...
   * @returns Void
   */
  addTelephone(): void {
    const control = <FormArray>this.generalCompanyInfoSection.get('telephones');
    /**
     * Add new form control for the new for the field that will be using the formControlName
     */
    control.push(this.initTelephone());
  }

  /**
   * initailise the Value of Export Sales for the past years
   * @returns FormGroup
   */
  initAnnualValofExportSaleslstYrs(): FormGroup {
    return this.fb.group({
      year: new FormControl('', []),
      amount: new FormControl('', [])
    });
  }

/**
 * This will add another field for annual sales
 */
  addAnnualValofExportSaleslstYrs(): void {
    const control = <FormArray>this.finalcialInformationSection.get('annualValofExportSalesLstYrs');
    /**
     * Add new form control for the new for the field that will be using the formControlName
     */

    control.push(this.initAnnualValofExportSaleslstYrs());
  }

  /**
   * @returns FormGroup
   */
  initService(): FormGroup {
    return this.fb.group({
      service: new FormControl(''),
    });
  }




  dumpValues1(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });
  
      if (valid === true) {
        this.isCompleted1 = true ;
        console.log("IS COMPLETED ===>> " ,completed)
      } else {
        this.isCompleted1 = false;
      }
    }


    dumpValues2(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });
  
      if (valid === true) {
        this.isCompleted2 = true ;
        console.log("IS COMPLETED ===>> " ,completed)
      } else {
        this.isCompleted2 = false;
      }
    }


    dumpValues3(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });

      if (valid === true) {
        this.isCompleted3 = true ;
        console.log('IS COMPLETED ===>> ' , completed);
      } else {
        this.isCompleted3 = false;
      }
    }

    dumpValues4(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });
  
      if (valid === true) {
        this.isCompleted4 = true ;
        console.log('IS COMPLETED ===>> ' , completed);
      } else {
        this.isCompleted4 = false;
      }
    }

    dumpValues5(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });
  
      if (valid === true) {
        this.isCompleted5 = true ;
        console.log("IS COMPLETED ===>> " ,completed)
      } else {
        this.isCompleted5 = false;
      }
    }

    dumpValues6(form: FormGroup, completed: boolean) {
      console.log(form);
      let valid = true;
      console.log(form);
      Object.keys(form.controls).forEach(key => {
      //  this.generalCompanyInfoSection.get(key).valid === false ? valid = false : valid = false ;
      valid = valid && form.get(key).valid;
        console.log('STATUS FOR THE FORM STEP:=>', key, form.get(key).status);
      });
  
      if (valid === true) {
        this.isCompleted6 = true ;
        console.log("IS COMPLETED ===>> " ,completed)
      } else {
        this.isCompleted6 = false;
      }
    }




  /**
   * @returns Void
   */
  addService(): void {
    const control = <FormArray>this.generalCompanyInfoSection.get('addresses');
    /**
     * Add new form control for the new for the field that will be using the formControlName
     */
    control.push(this.initService());
  }

  /**
   * @param parentArray This is the parent of the form array to remove child element from
   * @param childElement This the index of the child element to be remove
   * @returns Void
   */
  remove(parentArray: FormArray , childElement: number): void {
    parentArray.removeAt(childElement);
    console.log(parentArray, 'CHILD INDEX :', childElement);
  }




  // validates the email address entered by the user
  // the response is then subcribe to
  /**
   *
   * @param control this is the control that will be recieved to validate the imput
   */
  validateEmailNotTaken(control: AbstractControl): null | ValidationErrors  {
    return this.serverHttpCall.checkEmailNotTaken(control.value).subscribe(res => {
      // response is defined it will return null else it will return the {emailTaken: boolean }
      console.log('Response Recieved :', res);
      return res === false ? null : { emailTaken: true };
    });
  }



  /**
   * upload Event handler for the financila report files
   * @returns void
   */
 uploadFinancialReportFiles(formData) {
  const folder = 'FinancialReportFiles';
  const path =  `contractor/upload/${folder}/${this.generalCompanyInfoSection.get('companyName').value}`;
  console.log('SEDNING DATA TO THE SERVER FOR FINANCIAL FILES');
   this.serverHttpCall.uploadFiles(this.financiaFiles, path).subscribe(e => {
     console.log(e);

     setTimeout(() => {
      // remove all the error messages
      this.financialFileUploadSuccess.splice(0,this.financialFileUploadSuccess.length)
     },1500);

     this.finalcialInformationSection.get('financialFolderDir')
     .setValue(`${folder}/${this.generalCompanyInfoSection.get('companyName').value}`);


   }, (error) => {
     if (error) {
       console.log(error);
       this.financialFileUploadSuccess.push({severity: 'error',
       summary: 'Financial Files Uploads Error', detail: 'Financial Files were not uploaded'});

       setTimeout(() => {
         // remove all the error messages
         this.errorMessage.splice(0,this.errorMessage.length);
        },1500);

     }
   });
  }


  /**
   * upload Event handler for thetechnical capabilites files
   * certification files on the techincal section
   * @returns void
   */
 uploadTechnicalCapFiles(formData) {
    const folder = 'TechnicalCapabilityFiles';
    const path =  `contractor/upload/${folder}/${this.generalCompanyInfoSection.get('companyName').value}`;
    console.log('SEDNING DATA TO THE SERVER FOR TECHNOCALFILES');

    this.serverHttpCall.uploadFiles(this.techFiles, path).subscribe(e => {
      console.log(e);
      setTimeout(()=>{
        this.techFilesUploadSuccess.splice(0,this.techFilesUploadSuccess.length);
       }, 1500);

       this.techCapability.get('techFilesDir').setValue(`${folder}/${this.generalCompanyInfoSection.get('companyName').value}`);

    }, (error) => {
      if (error) {
        console.log(error);
        this.techFilesUploadSuccess.push({severity: 'error', 
        summary:'Techincal Files Uploads Error', detail:'Your files were successfully uploaded'});

        setTimeout(() => {
          // remove all the error messages
          this.errorMessage.splice(0,this.errorMessage.length);
        }, 1500);
      }
    });
  }

  /**
   * upload Event handler for the certification files files
   * This should be the last part of the registeration
   * @returns void
   */
 onUploadCerticates(formData) {
  const folder = 'CompanyCertificatesFiles';
  const path =  `contractor/upload/${folder}/${this.generalCompanyInfoSection.get('companyName').value}`;
  console.log('SEDNING DATA TO THE SERVER FOR COMAPNY CERTIFICATES');
  this.serverHttpCall.uploadFiles(this.compCertFiles, path).subscribe(e => {
    console.log(e);
    this.compCertFilesUploadSuccess.push({severity:'success', summary:'Certificates where uploaded',
     detail:'Your uploads was successful!'});

     setTimeout(()=>{
      this.compCertFilesUploadSuccess.splice(0,this.compCertFilesUploadSuccess.length)
     }, 1500);

     this.othersSection.get('certificationsDir').setValue(`${folder}/${this.generalCompanyInfoSection.get('companyName').value}`);



  },(error)=>{
    if(error){
      console.log(error);
      this.messageService.add({severity:'info', summary:'Certificates Uploads failed', 
      detail:'Your certicates files didnt upload successfully'});
      setTimeout(()=>{
        // remove all the error messages
        this.errorMessage.splice(0,this.errorMessage.length);
      }, 1500);
    }
  });
}




  postFormToServer(formvalueToPost: []): void {

  }

  /**
   * Check general section
   */




   /**
   * Check general section
   */
  validateFinalSection(): boolean {
    return this.finalcialInformationSection.status === 'VALID' ? true : false ;
  }

  validateGenSection(): boolean {
    return this.generalCompanyInfoSection.status === 'VALID' ? true : false ;
  }

  validateExperiencesSection(): boolean {
    return this.experiencesSection.status === 'VALID' ? true : false ;
  }




  asyncValidator(formGroup: AbstractControl): Promise<ValidationErrors | null > | null {
    Object.keys(formGroup).forEach(key => {
      const valid = this.finalcialInformationSection.get(key).invalid ;
      return valid === true ? {error: true} : null ;
    });

    return null ;
  }


  /**
   *
   * @param answer The is te check box value
   */
  questionOneAdd(answer: string): void {
    this.othersSection.get('questionOne').setValue(answer);
    console.log(this.othersSection.get('questionOne').value)
  }

  /**
   *
   * @param answer this the check box value
   */
  questionTwoAdd(answer: string): void {
    this.othersSection.get('questionTwo').setValue(answer);
    console.log(this.othersSection.get('questionTwo').value)

  }

  /**
    * Finalise the registerationa and send it to the server
    */
  finaliseRegisteration() {
this.techCapability.get("services").setValue(this.servicesChecked);
    const valGen: InterfaceGetAll = this.getAllFormGroupValue(this.generalCompanyInfoSection);
    const valFin: InterfaceGetAll  = this.getAllFormGroupValue(this.finalcialInformationSection);
    const valOther: InterfaceGetAll = this.getAllFormGroupValue(this.othersSection);
    const valLogCre: InterfaceGetAll  = this.getAllFormGroupValue(this.logginCredentialSection);
    const valTechCap: InterfaceGetAll = this.getAllFormGroupValue(this.techCapability);
    const valExp: InterfaceGetAll  = this.getAllFormGroupValue(this.experiencesSection);

    // test the form  that would be sent to the server
    console.log('This is the form data that would be saved on the server', this.formDataToSend);

    const data = [];
    data.push(valGen, valFin, valOther, valLogCre, valTechCap, valExp);
    this.formDataToSend['generalCompanyInfoSection'] = valGen ;
    this.formDataToSend['othersSection'] = valOther ;
    this.formDataToSend['experiencesSection'] = valExp ;
    this.formDataToSend['techCapability'] = valTechCap;
    this.formDataToSend['logginCredentialSection'] = valLogCre ;
    this.formDataToSend['finalcialInformationSection'] = valFin ;





 

    console.log('This is the data ', this.formDataToSend);
    /*
    console.log(this.generalCompanyInfoSection,this.othersSection,this.experiencesSection,this.techCapability,this.logginCredentialSection)
    */
    this.serverHttpCall.createNewContractor(this.formDataToSend).subscribe(e => {
      console.log('Something was returned...');
      console.log(e);
    });
  }

  /**
   *
   * @param formGroup This is the form group object that input values will be extracted from.
   */
  getAllFormGroupValue(formGroup: FormGroup):InterfaceGetAll {
    const returnValue = {};
    Object.keys(formGroup.controls).forEach(key => {
      if(key != 'confirmPassword'){
        typeof formGroup.controls[key].value === 'object' ?
        returnValue[key] = JSON.stringify(formGroup.controls[key].value) : returnValue[key] = formGroup.controls[key].value ;
        console.log('Key Found===>', returnValue);
      }

    });
    return returnValue ;
  }


/**
 * This line of code upload the financial fials of the company
 * Please dont touch... dont breake the flow of the program
 */
  getFinFiles(event) {
    this.financiaFiles = [];
    for (let i = 0 ; i < event.target.files.length ; i++) {
     this.financiaFiles.push(this.fileReadAsBuffer(event.target.files[i]));
    }
    console.log(this.financiaFiles);
}

/**
 * Uploads technical files of the comopany 
 */
getTechFiles(event) {
  this.techFiles = [] ;
  for (let i = 0 ; i < event.target.files.length ; i++) {
   this.techFiles.push(this.fileReadAsBuffer(event.target.files[i]));
  }
  console.log(this.techFiles);
}

getCompFiles(event) {
  this.compCertFiles = [];
  for (let i = 0 ; i < event.target.files.length ; i++) {
   this.compCertFiles.push(this.fileReadAsBuffer(event.target.files[i]));
  }
  console.log(this.compCertFiles);
}

fileReadAsBuffer(file): any {
    this.results = [] ;
    const fileObject: {filename: string , data: any} = {filename : '' , data : null};
    const fileReader = new FileReader();
    fileReader.readAsArrayBuffer(file) ;

     fileReader.onload = (): any => {
      this.arrayBufferResult  = <ArrayBuffer>fileReader.result;
      const arrayBufferView = new Int8Array(this.arrayBufferResult);
      const buffer = [] ; buffer.length = arrayBufferView.byteLength ;
      for (let i  = 0 ; i < buffer.length ; i ++ ) {
        buffer[i] = arrayBufferView[i];
      }

      fileObject.filename = file.name ;
      fileObject.data = buffer ;

      // this.results.push(fileObject);
      // console.log('Buffer ====>', buffer) ;
      // console.log(fileObject);
    };
    return fileObject ;
  }



  /**
   * add and service the service into
   */
  checkAndAddToServices(event: MatCheckboxChange,i: number,service:string){
    if(event.checked === true){
      this.servicesChecked.push(service);
      console.log(this.servicesChecked)
    }else if(event.checked === false ){
      this.servicesChecked.splice(this.servicesChecked.indexOf(service),1);
      console.log(this.servicesChecked)
    }
  }
}
 

export interface InterfaceGetAll {
  [key: string]: {val: Array<string | number | boolean> | string} ;
} 



import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyRegistrationPageComponent } from './company-registration-page.component';

describe('CompanyRegistrationPageComponent', () => {
  let component: CompanyRegistrationPageComponent;
  let fixture: ComponentFixture<CompanyRegistrationPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyRegistrationPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyRegistrationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

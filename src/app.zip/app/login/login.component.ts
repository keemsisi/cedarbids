import { Component, OnInit } from '@angular/core';
import {FormBuilder , FormControl, FormGroup} from '@angular/forms' ;
import {HttpClient, HttpErrorResponse } from '@angular/common/http' ;
import {Resolve, ActivatedRoute, Router} from '@angular/router';
import { HttpCustomService } from '../services/http-custom.service';
import { error } from 'util';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  password: string;
  username: string ;

  // Login Form group 
  loginForm: FormGroup ;

  constructor(
    private customHttpService:HttpCustomService ,
    private activatedRoute: ActivatedRoute,
    private router: Router, private fb: FormBuilder
    ) {
      this.loginForm = this.fb.group({
        username: new FormControl(''),
        password: new FormControl('')
      });
  }

  ngOnInit() {
  }

  grantLogin() {

  }

  /**
   * @param loginParameter the login parameter the user entered in the input fields
   */
  onLoginClick(): void {
    this.customHttpService.sendLoginParameters(this.username, this.password).subscribe(
      data => {
        console.log(data);
        // if grant is true then grant the user access to the dashboard
        if (data.hasAccess === true ){
          // navigate the contractor the dashboard
          this.router.navigateByUrl('/contractor-dashboard');
        } else {
          console.log('Access Denied!\nLogin Credentials does not match or User is not registered!...');
        }
    }, ( err: HttpErrorResponse) => {
        console.log(err);
    });
  }
}

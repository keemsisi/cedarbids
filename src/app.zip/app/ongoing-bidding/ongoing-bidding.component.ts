import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ongoing-bidding',
  templateUrl: './ongoing-bidding.component.html',
  styleUrls: ['./ongoing-bidding.component.css']
})
export class OngoingBiddingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoingBiddingComponent } from './ongoing-bidding.component';

describe('OngoingBiddingComponent', () => {
  let component: OngoingBiddingComponent;
  let fixture: ComponentFixture<OngoingBiddingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OngoingBiddingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoingBiddingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

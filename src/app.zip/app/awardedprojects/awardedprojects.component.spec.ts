import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AwardedprojectsComponent } from './awardedprojects.component';

describe('AwardedprojectsComponent', () => {
  let component: AwardedprojectsComponent;
  let fixture: ComponentFixture<AwardedprojectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AwardedprojectsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AwardedprojectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

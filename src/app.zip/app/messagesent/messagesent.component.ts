import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messagesent',
  templateUrl: './messagesent.component.html',
  styleUrls: ['./messagesent.component.css']
})
export class MessagesentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

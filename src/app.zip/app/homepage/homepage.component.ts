import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HttpCustomService } from '../services/http-custom.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HomepageComponent implements OnInit {

   private counter: Array<number> = [34,4,34,34,34,43,43,43,4,3,4,34,3,43,4,3,4,34,3,5,45,4,5,45,4,453,4,,42,3,23] ;
  constructor(private http: HttpCustomService) { }

  ngOnInit() {
    this.http.testConnectionWithServerApplication().subscribe(
      map => {
        console.log('<===================NG OnInit========>>>>>>');
        console.log(map);
      }
    ) ;
  }

}

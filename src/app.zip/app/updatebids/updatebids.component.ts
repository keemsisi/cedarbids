import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatebids',
  templateUrl: './updatebids.component.html',
  styleUrls: ['./updatebids.component.css']
})
export class UpdatebidsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

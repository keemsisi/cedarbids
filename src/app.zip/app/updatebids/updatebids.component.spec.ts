import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatebidsComponent } from './updatebids.component';

describe('UpdatebidsComponent', () => {
  let component: UpdatebidsComponent;
  let fixture: ComponentFixture<UpdatebidsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatebidsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatebidsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

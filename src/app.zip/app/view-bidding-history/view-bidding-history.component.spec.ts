import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBiddingHistoryComponent } from './view-bidding-history.component';

describe('ViewBiddingHistoryComponent', () => {
  let component: ViewBiddingHistoryComponent;
  let fixture: ComponentFixture<ViewBiddingHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBiddingHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBiddingHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

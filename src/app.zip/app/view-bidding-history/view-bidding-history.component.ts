import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-bidding-history',
  templateUrl: './view-bidding-history.component.html',
  styleUrls: ['./view-bidding-history.component.css']
})
export class ViewBiddingHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

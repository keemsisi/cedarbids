import { Component, OnInit, Output, Input } from '@angular/core';
import { EventEmitter } from 'events';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {

  someValue: string;
  constructor() { }


  // @Input()
  // @Output() counterChange = new EventEmitter();
  get something() {
    console.log('hello');
    // this.counterChange.emit('rererer');
    return 3434;
  }

  ngOnInit() {
    console.log('The contact Us worked!!!!');
  }

}

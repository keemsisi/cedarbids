import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bids-statistics',
  templateUrl: './bids-statistics.component.html',
  styleUrls: ['./bids-statistics.component.css']
})
export class BidsStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

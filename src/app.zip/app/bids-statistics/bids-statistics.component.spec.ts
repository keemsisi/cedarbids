import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BidsStatisticsComponent } from './bids-statistics.component';

describe('BidsStatisticsComponent', () => {
  let component: BidsStatisticsComponent;
  let fixture: ComponentFixture<BidsStatisticsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BidsStatisticsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BidsStatisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

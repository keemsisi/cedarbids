import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AvailaibleGoodsAndServeService {
  private _servicesAvailable: Array<string>;
  constructor() {
    this._servicesAvailable = [
        'Networking and Telecommunications',
        'Computer Securities',
        'IT Consultancy',
        'Food items & Food and Nutrition consultancy Construction material',
        'Food Processing Machinery and rice mills Construction services',
        'Packaging Materials & equipment, poly bags 25 or 30 or 50 kg Medical supplies & Consultancy',
        'Warehouses and warehouse equipment, pallets Air-conditioners and maintenance services',
        'Fumigants Office administration related services',
        'Light Vehicles and spare parts Staff uniform and shoes',
        'Heavy vehicles and spare parts Office furniture or wooden items',
        'Road cleaning & Engineering equipment services & consultancy Stationary & Paper',
        'Tyres Office consumables',
        'Honda Motorcycle and spares Printing and photo-copying services',
        'Transportation services Media & Advocacy Consulting and training',
        'Forwarding and clearing services Legal Services & Consultancy',
        'Superintendent services, quality and quantity control Agricultural machines /materials & consultancy',
         'Fuel or oil and lubricants Security equipment and services',
        'Fuel storage and Pumps Port services',
        'Generators and spares Investment services and consultancy',
        'Electric materials and appliances Publishing Services and Consultancy',
        'Architectural design services Postal and courier services',
        'IT equipment (computers, printers, scanners etc) and consultancy Custom clearance services',
        'TC equipment (mobile phones, HF or VHF radio equipment) Travel agency',
        'Software and Software or WEB design and training Hotel and restaurant',
        'General electronics and photo equipment & Services'
    ];
   }

   get servicesOffering(): Array<string> {
     return this._servicesAvailable ;
   }
}

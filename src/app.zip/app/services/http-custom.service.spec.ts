import { TestBed, inject } from '@angular/core/testing';

import { HttpCustomService } from './http-custom.service';

describe('HttpCustomService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpCustomService]
    });
  });

  it('should be created', inject([HttpCustomService], (service: HttpCustomService) => {
    expect(service).toBeTruthy();
  }));
});

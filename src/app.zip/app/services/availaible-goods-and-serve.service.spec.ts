import { TestBed } from '@angular/core/testing';

import { AvailaibleGoodsAndServeService } from './availaible-goods-and-serve.service';

describe('AvailaibleGoodsAndServeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AvailaibleGoodsAndServeService = TestBed.get(AvailaibleGoodsAndServeService);
    expect(service).toBeTruthy();
  });
});

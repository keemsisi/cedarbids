import { Injectable} from '@angular/core';
import { Resolve, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CacheCustomService } from './cache-custom.service';
import { AbstractControl } from '@angular/forms';

// import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/delay';
// import {map} from 'rxjs/add/operator';
// import {delay} from 'rxjs/add/operator';



@Injectable({
  providedIn: 'root'
})

export class HttpCustomService {

  constructor(private http: HttpClient , private cacheService: CacheCustomService) {
   }

   getBiddingProgresses(contractorId: string , biddingId: string): Observable<any> {
     return this.http.get(
       this.cacheService.urlEndPoint + `/contractor/${contractorId}/applied/bidding/progress/${biddingId}`, {responseType : 'text'}) ;
   }

   getBiddingStatistics(contractorId: string) {
    return this.http.get(this.cacheService.urlEndPoint + `bidding/applied/statistics/contractor/${contractorId}`);
   }

   /**
    *
    * @param username The passed username from the input field
    * @param password The passed password from the input field 
    */
   sendLoginParameters(username: string,password : string): Observable<any> {
     const contractorLoginParameter = {'username': username , 'password': password };

    return this.http.post(this.cacheService.urlEndPoint + `/login/contractor/grant/`, contractorLoginParameter, {responseType: 'json'});
   }

   /**
    * When contraactor creates new bidding
    */
   /**
    * 
    * @param newBiddingCredential The bidding credentials for the new bid created by the contractor 
    */
   createNewBidding(newBiddingCredential): Observable<any> {
     return this.http.post(this.cacheService.urlEndPoint + '/contractor/create/new/bidding', newBiddingCredential );
   }


   /**
    * 
    * @param newContractor The form object to be sent to the server
    */
   createNewContractor(newContractor: {}): Observable<any> {
    return this.http.post(this.cacheService.urlEndPoint +`/create/new/contractor`,newContractor,{responseType: 'json'}
       );
   }

   testConnectionWithServerApplication(): Observable<any> {
     const b   = new FormData() ;
     const c = new FileReader();

     // return this.http.get('http://localhost:3600/testing/route', {responseType: 'text'}) ;
     const body = {
       'name': 'lasisi akeem',
       'school': 'funaab',
       'scholarship': 'Software engineering scholarship'
      };
     b.append('body' , JSON.stringify(body)) ;
    // return this.http.get('http://localhost:3600', {responseType: 'text'}) ;
    return this.http.put('http://localhost:3600/test/post', b);
   }



   // check if the email is available or taken
   /**
    *
    * @param email The email to check if it already exists. The eamil is of the type string
    */
   checkEmailNotTaken(email: string): Observable<any> {
     // returns a json format
    const valueReturned =  this.http.get(this.cacheService.urlEndPoint + `/check/email/taken/?email=${email}`, {responseType: 'json'});
    console.log(valueReturned);
    return valueReturned;
   }


   /**
    *
    * @param objectURL This is the string the function will receive to get the array object of the file the use upload
    * @returns Observable<ArrayBuffer> Return type for the method when it finishes its excution.
    */
   uploadFiles(data, path: string): Observable<any> {
     console.log('URL RECEIVED ===>', path);
     console.log('DATA RECEIVED ====>', data );
     const header = new HttpHeaders();
     header.set('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
     header.set('Access-Control-Allow-Origin', '*');
     return this.http.post(`http://localhost:3500/${path}`, JSON.stringify(data), {responseType: 'json', headers: header});
   }

  //  getFileFromURL (objectURL:string):ArrayBuffer {
  //   console.log("URL RECEIVED ===>",objectURL)
  //   var returnValue:ArrayBuffer = new ArrayBuffer(0);
  //   var xml = new XMLHttpRequest();
  //   xml.responseType = "arraybuffer"
  //   xml.open("get",objectURL);
  //   xml.send();
  //   xml.onreadystatechange = ()=>{
  //     if (xml.readyState === 4 ){
  //       returnValue =  xml.response ;
  //     }
  //   }
  //   return returnValue ;
  // }

}


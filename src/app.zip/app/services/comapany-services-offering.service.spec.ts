import { TestBed } from '@angular/core/testing';

import { ComapanyServicesOfferingService } from './comapany-services-offering.service';

describe('ComapanyServicesOfferingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ComapanyServicesOfferingService = TestBed.get(ComapanyServicesOfferingService);
    expect(service).toBeTruthy();
  });
});

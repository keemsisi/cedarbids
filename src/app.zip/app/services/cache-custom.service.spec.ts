import { TestBed, inject } from '@angular/core/testing';

import { CacheCustomService } from './cache-custom.service';

describe('CacheCustomService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CacheCustomService]
    });
  });

  it('should be created', inject([CacheCustomService], (service: CacheCustomService) => {
    expect(service).toBeTruthy();
  }));
});

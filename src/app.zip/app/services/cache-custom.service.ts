import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CacheCustomService {
  readonly ipAddress = 'localhost';
  readonly urlEndPoint = `http://${this.ipAddress}:3500`;

  constructor() {}
}
